Welcome to the KLatexFormula installer.
