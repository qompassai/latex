#!/bin/bash

cd KLFOOo-oxt && zip -vr ../KLFOOo.oxt . --exclude '*.svn/' --exclude '*.svn/*' @

